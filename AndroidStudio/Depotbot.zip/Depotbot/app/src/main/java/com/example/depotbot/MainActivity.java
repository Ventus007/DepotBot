package com.example.depotbot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.graphics.Color;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton radioButton;
    TextView textViewOrigen;
    TextView textViewDestino;
    int cont = 0;
    RadioButton origen, destino;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewOrigen = findViewById(R.id.text_selected_origin);
        textViewDestino = findViewById(R.id.text_selected_destiny);


        Button buttonApply = findViewById(R.id.button_apply);
        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cont == 0)
                {
                    origen = radioButton;
                    textViewOrigen.setText("Selected origin point: " + radioButton.getText());
                    radioButton.setBackgroundColor(Color.GREEN);
                    cont++;
                }
                else if (cont == 1)
                {
                    destino = radioButton;
                    textViewDestino.setText("Selected destination point: " + radioButton.getText());
                    radioButton.setBackgroundColor(Color.RED);
                    cont++;
                }
            }
        });

        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont = 0;
                textViewOrigen.setText("Selected origin point: ");
                textViewDestino.setText("Selected destination point: ");
                origen.setBackgroundColor(Color.TRANSPARENT);
                destino.setBackgroundColor(Color.TRANSPARENT);

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.itemSeguidor:
                Toast.makeText(this, "Seguidor de lineas", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.itemManual:
                Toast.makeText(this, "Manual", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, ManualActivity.class));
                return true;
            case R.id.itemAutonom:
                Toast.makeText(this, "Autonom", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void checkButton(View v) {
        RadioButton rb = (RadioButton) v;
        if (radioButton != null)
            radioButton.setChecked(false);
        rb.setChecked(true);
        radioButton = rb;
    }
}
