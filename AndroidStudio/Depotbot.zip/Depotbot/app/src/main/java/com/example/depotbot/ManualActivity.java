package com.example.depotbot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;
import android.os.Bundle;

public class ManualActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.itemSeguidor:
                Toast.makeText(this, "Seguidor de lineas", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ManualActivity.this, MainActivity.class));
                return true;
            case R.id.itemManual:
                Toast.makeText(this, "Manual", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.itemAutonom:
                Toast.makeText(this, "Autonom", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ManualActivity.this, MainActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
